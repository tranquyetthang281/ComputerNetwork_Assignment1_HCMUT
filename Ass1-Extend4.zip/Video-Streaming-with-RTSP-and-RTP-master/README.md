# Extend 4 . Implement some additional functions for user interface such as: display video total time and remaining time
1. Client.py
- Add self.frames, duration, fps
- Add clock function
- createWidgets(): Add self.timer

2. ServerWorker.py
- replyRtsp(): Add string message(duration, fps) to reply

3. VideoStream.py
- Add self.duration, fps
