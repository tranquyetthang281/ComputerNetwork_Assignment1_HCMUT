import numpy as np
import cv2
class VideoStream:
	def __init__(self, filename):
		self.filename = filename
		try:
			self.file = open(filename, 'rb')
		except:
			raise IOError
		self.frameNum = 0
		
		video_capture = cv2.VideoCapture(self.filename)
		video_length = int(video_capture.get(cv2.CAP_PROP_FRAME_COUNT))
		count  = 0
		while True:
			ret, frame = video_capture.read()
			if not ret:
				break 
			count += 1
		
		fps = int(video_capture.get(cv2.CAP_PROP_FPS))
		video_capture.release()
		cv2.destroyAllWindows()
		self.duration = int(count/fps) 
		self.fps = int(fps)
		
	def nextFrame(self):
		"""Get next frame."""
		data = self.file.read(5) # Get the framelength from the first 5 bits
		if data: 
			framelength = int(data)
			print(framelength)				
			# Read the current frame
			data = self.file.read(framelength)
			self.frameNum += 1
		return data
		
	def frameNbr(self):
		"""Get frame number."""
		return self.frameNum


v = VideoStream("MyMovie17.Mjpeg")
print(v.duration,v.fps)


	
	